package com.Prospecta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ProspectaCodingChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProspectaCodingChallengeApplication.class, args);
	}

}
