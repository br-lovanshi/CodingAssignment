package com.Prospecta.exception;

public class Scienceexception extends Exception {

	
	public Scienceexception(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	public Scienceexception() {
		// TODO Auto-generated constructor stub
	}
	
}
